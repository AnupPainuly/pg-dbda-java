package p1;

public class Tester {

	public static void main(String[] args) {
		//add 2 nums
		Adder a=new Adder();
		System.out.println(a.compute(10, 20));
		//multiply 2 nums
		Multiplier m=new Multiplier();
		System.out.println(m.compute(11, 12));

	}
	
}
