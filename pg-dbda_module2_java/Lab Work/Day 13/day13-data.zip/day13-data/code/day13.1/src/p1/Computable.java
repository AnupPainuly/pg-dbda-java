package p1;

@FunctionalInterface
public interface Computable {
	// add a method declaration (public abstract) to compute ANY op on the double
	// operands
	double compute(double d1,double d2);
	
}
