package p1;

public interface Printer {
//data members : public static final : implicitly added by javac
	int SPEED=50;
	//method : public abstract : implicitly added by javac
	void print(String mesg);
}
