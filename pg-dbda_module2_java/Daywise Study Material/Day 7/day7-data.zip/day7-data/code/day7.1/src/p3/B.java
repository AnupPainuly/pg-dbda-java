package p3;

public interface B {
	boolean isEven(int num);
}
