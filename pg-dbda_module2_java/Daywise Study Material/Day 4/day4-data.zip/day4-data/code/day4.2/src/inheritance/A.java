package inheritance;

public class A /*extends Object*/{
	public A() {
		System.out.println("in A");
	}
}
