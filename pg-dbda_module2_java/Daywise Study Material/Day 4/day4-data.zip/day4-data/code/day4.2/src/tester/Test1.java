package tester;

import inheritance.C;
//constr invocation in multi level hierarchy
public class Test1 {

	public static void main(String[] args) {
		C c1 = new C();

	}

}
