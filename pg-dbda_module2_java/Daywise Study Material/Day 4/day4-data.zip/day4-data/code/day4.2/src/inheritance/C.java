package inheritance;

public class C extends B {
	public C() {
		//super(); invoking immediate super cls's constr
		System.out.println("in C");
	}
}
